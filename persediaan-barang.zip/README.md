List Bug

1. warning stock datanya dari mana?
2. redirect url salah salah
3. popup warning stock selalu muncul disetiap pindah halaman

List Error

1. data master semua fitur hapus data error (data barang, jenis barang, satuan)
2. profil user (upload foto error)
3. edit data user

pertanyaan?

ada 3 level : super admin, manajer, gudang. tetapi semua level aksesnya sama. menampilkan semua fitur yang sama.

Saran Kami untuk hak aksesnya:
1.super admin : kelola semua fitur
2.manajer : laporan, manajemen user (opsional), edit profil.
3.gudang : transaksi, laporan, edit profil
